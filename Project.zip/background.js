browser.browserAction.onClicked.addListener(async () => {
    const tabs = await browser.tabs.query({
        //gets one tab window
        active: true,
        //gets current tab window
        currentWindow: true
    });

    //sends message to first tab/current (if you only have one tab)
    browser.tabs.sendMessage(tabs[0].id, {action : "test"})
})

browser.browserAction.onClicked.addListener(buttonClicked);

function buttonClicked(tab) {
    console.log(tab);
}